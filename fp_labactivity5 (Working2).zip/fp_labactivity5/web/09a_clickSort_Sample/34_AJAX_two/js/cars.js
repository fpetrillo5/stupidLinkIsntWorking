/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function cars() {
    var carsDOM = document.createElement("div");

    ajax("json/cars.json", callBack9, carsDOM);

    function callBack9(myObj) {
        console.log(myObj);
        //console.log(myObj.list);
//        
//                        var userList = [];
//
//                // modify properties (image and price) of the array of objects so it will look 
//                // better on the page.
//                for (var i = 0; i < myObj.length; i++) {
//
//                    userList[i] = {};
//                    // Don't show the id (no meaningful data)
//                    userList[i].image = "<img  src='" + myObj[i].image + "' style='width:5rem'>";
//                    userList[i].userEmail = myObj[i].userEmail; // show this first
//                    // Don't show the password
//                    userList[i].birthday = myObj[i].birthday;
//                    userList[i].membershipFee = myObj[i].membershipFee;
//                    userList[i].role = myObj[i].userRoleId + " " + myObj[i].userRoleType;
//                }
//                
//                console.log(myObj.userList);
        // modify properties (image and price) of the array of objects so it will look 
        // better on the page.
        for (var i = 0; i < myObj.length; i++) {
            myObj[i].image = "<img  src='" + myObj[i].image + "' style='width:10rem'>";
        }


        var cars1 = MakeTable({
            list: myObj 
        }); 
        cars1.classList.add("clickSort");
        carsDOM.appendChild(cars1);

    }
    ;

    return carsDOM;
}

