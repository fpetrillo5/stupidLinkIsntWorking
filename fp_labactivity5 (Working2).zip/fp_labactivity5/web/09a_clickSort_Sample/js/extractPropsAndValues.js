/*
 * Return a div that has one paragraph per property you find in obj. (You must iterate 
 * over the properties, not knowing what they might be...)
 * Each paragraph shall have this text: "The property named XXX has the value YYY".
 * Replace XXX with the property name. Replace YYY with the value of that propery.
 */


function extractPropsAndValues(obj) {
    var div = document.createElement("div");

    console.log(obj);


//    var p1 = document.createElement("p");
//    // p1.innerHTML = "check";
//    var test = document.getElementById("test"); can get rid of
//    test.appendChild(p1);
//
    // "prop" iterates through the properties that are in the object obj
    for (var prop in obj) {

        var p = document.createElement("p");

        div.appendChild(p);
        p.innerHTML = "The property named " + prop + " has the value " + obj[prop];

        //how am i not going to override p everytime, it will jst have last p


        // even though "prop" is a character string (field name), you can use it 
        // as if it were an index value inside of square brackets - this returns the 
        // value of the property. This is called "associative array notation" (when 
        // you use a property name as if it were an index value - returns the value of the property.


        //console.log('property is ' + prop + ' and its value is ' + obj[prop]);
    }

    // console.log("end of showProps")


    return div;
}

