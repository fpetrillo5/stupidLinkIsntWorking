function MakeTable(list) {

    // Add data as th or td (based on eleType) to row of HTML table.
    function addToRow(eleType, row, data) {
        var ele = document.createElement(eleType);
        ele.innerHTML = data;
        row.appendChild(ele);
    }

    // Main Program.

    // Create a new HTML table (DOM object) and append 
    // that into the page. 
    var newTable = document.createElement("table");

    // Add one row (to HTML table) per element in the array.
    // Each array element has a list of properties that will become 
    // td elements (Table Data, a cell) in the HTML table. 
    var tableBody = document.createElement("tbody");
    newTable.appendChild(tableBody);
    for (var i in list) {
        var tableRow = document.createElement("tr");
        tableBody.appendChild(tableRow);

        // create one table data <td> content matching the property name
        var obj = list[i];
        for (var prop in obj) {
            addToRow("td", tableRow, obj[prop]);
        }
    }

    return newTable;

}  // MakeTable