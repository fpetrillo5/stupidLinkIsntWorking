/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function MakePagination(params){
    
    var pagainationDOM = document.createElement("div");
    
     if (!params.objList || !params.objList[0]) {
       alert("Must provide an object with at least one property of ");

        return;
    }
    
    pagainationDOM.rows = params.rows || 5;
    var currPage = 1;
    
    function SetupPagination () {
	

	var pageCount = Math.ceil(params.objList.length / params.rows);
        console.log(pageCount);
	for (var i = 1; i < pageCount + 1; i++) {
		var btn = PaginationButton(i);
		pagainationDOM.appendChild(btn);
	}
}

function PaginationButton (index) {
	var button = document.createElement('button');
	button.innerText = index;

	if (currPage === index) button.classList.add('active');

	button.addEventListener('click', function () {
		currPage = index;
                console.log(currPage);
		DisplayList(items, list_element, rows, current_page);

		var currBtn = document.querySelector('.pagenumbers button.active');
		currBtn.classList.remove('active');

		button.classList.add('active');
	});
        }


    
    return pagainationDOM;
    
}
