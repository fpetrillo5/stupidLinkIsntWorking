
function MakePagination(params) {

    var paginationDOM = document.createElement("div");

    var list = document.createElement("div");
    list.classList.add("paginationStyle");
    paginationDOM.appendChild(list);

    var pagination = document.createElement("div");
     pagination.classList.add("paginationStyle");
    paginationDOM.appendChild(pagination);

    if (!params.list || !params.list[0]) {
        alert("Must provide an object with at least one property of ");

        return;
    }

    paginationDOM.list = params.list;
    paginationDOM.rows = params.rows || 5;
    var currPage = 1;

    var pageCount = Math.ceil(paginationDOM.list.length / paginationDOM.rows);

    function showList(items, container, rowsPage, curr) {
        container.innerHTML = "";
        curr--;

        var start = rowsPage * curr;
        var end = start + rowsPage;
        var paginatedItems = items.slice(start, end);

        for (let i = 0; i < paginatedItems.length; i++) {
            var item = paginatedItems[i];
            var itemsElement = document.createElement('div');
            itemsElement.classList.add('item');
            itemsElement.innerHTML = item.name;
            container.appendChild(itemsElement);
        }
    }

    function buildPagination(items, container, pageCount) {
        container.innerHTML = "";

        for (var i = 1; i < pageCount + 1; i++) {
            var btn = paginationButton(i, items);
            container.appendChild(btn);
        }
    }

    function paginationButton(index, items) {
        var button = document.createElement('button');
        button.innerHTML = index;
        button.className = "paginationStyle";

        //if (currPage === index);
        //button.classList.add('active');

        button.addEventListener('click', function () {
            currPage = index;
            console.log(currPage);
            setButtonState();
            showList(items, list, paginationDOM.rows, currPage);

            var currentBtn = document.querySelector('.pagenumbers button.active');
            //currentBtn.classList.remove('active');

            // button.classList.add('active');
        });

        return button;
    }

    function setButtonState() {
        if (currPage <= 1) {
            backButton.disabled = true;
            firstButton.disabled = true;
        } else {
            backButton.disabled = false;
            firstButton.disabled = false;
        }


        if (currPage >= pageCount) {
            fwdButton.disabled = true;
            lastButton.disabled = true;
        } else {
            fwdButton.disabled = false;
            lastButton.disabled = false;
        }
    }

    var dropDown = document.createElement("select");
    dropDown.onchange = function() {
       currPage= this.selectedIndex +1;
        setButtonState();
        showList(paginationDOM.list, list, paginationDOM.rows, currPage);
    };
    paginationDOM.appendChild(dropDown);

    //public function

    for (var i = 0; i < pageCount; i++) {
        var option = document.createElement("option");
        option.text = "Page " + (i + 1);
        option.value = i;
        
        dropDown.add(option);
    }


    var firstButton = document.createElement("button");
    firstButton.disabled = true;
    firstButton.innerHTML = " &lt;&lt; ";
    paginationDOM.appendChild(firstButton);

    //add back button and put it on page
    var backButton = document.createElement("button");
    backButton.disabled = true;
    backButton.innerHTML = " &lt; ";
    paginationDOM.appendChild(backButton);

    //add forward button and put it on page
    var fwdButton = document.createElement("button");
    if (currPage >= pageCount) {
        setButtonState();
    }
    fwdButton.innerHTML = " &gt; ";
    paginationDOM.appendChild(fwdButton);

    var lastButton = document.createElement("button");
    if (currPage >= pageCount) {
        setButtonState();
    }
    lastButton.innerHTML = " &gt;&gt; ";
    paginationDOM.appendChild(lastButton);

    function nextPage() {
        currPage++;
        setButtonState();
        showList(paginationDOM.list, list, paginationDOM.rows, currPage);

    }

    function prevPage() {
        currPage--;
        setButtonState();
        showList(paginationDOM.list, list, paginationDOM.rows, currPage);
    }

    function firstPage() {
        currPage = 1;
        setButtonState();
        showList(paginationDOM.list, list, paginationDOM.rows, currPage);
    }

    function lastPage() {
        currPage = pageCount;
        setButtonState();
        showList(paginationDOM.list, list, paginationDOM.rows, currPage);
    }

    backButton.onclick = prevPage;
    fwdButton.onclick = nextPage;
    firstButton.onclick = firstPage;
    lastButton.onclick = lastPage;

    showList(paginationDOM.list, list, paginationDOM.rows, currPage);
    buildPagination(paginationDOM.list, pagination, pageCount);

    return paginationDOM;

}

