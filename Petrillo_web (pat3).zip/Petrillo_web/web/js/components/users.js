/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function users() {
    var usersDOM = document.createElement("div");

    ajax("json/users.json", callBack1, usersDOM);

    function callBack1(myObj) {
        // modify properties (image and price) of the array of objects so it will look 
        // better on the page.
        for (var i = 0; i < myObj.length; i++) {
            myObj[i].image = "<img  src='" + myObj[i].image + "' style='width:10rem'>";
        }


        var users1 = MakeClickSort({
            list: myObj,
            sortOrderPropName: "webUserId",
            header: "Users"
        }); //might need to pass title as well
        users1.classList.add("clickSort");
        usersDOM.appendChild(users1);

    }
    ;

    return usersDOM;
}


