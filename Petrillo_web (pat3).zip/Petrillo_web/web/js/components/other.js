/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function other() {
    var otherDOM = document.createElement("div");

    ajax("json/Other.json", callBack2, otherDOM);

    function callBack2(myObj) {

        // modify properties (image and price) of the array of objects so it will look 
        // better on the page.
        for (var i = 0; i < myObj.length; i++) {
            myObj[i].image = "<img  src='" + myObj[i].image + "' style='width:10rem'>";
        }


        var other1 = MakeClickSort({
            list: myObj,
            sortOrderPropName: "itemsContributedID",
            header: "Others"
        }); //might need to pass title as well
        other1.classList.add("clickSort");
        otherDOM.appendChild(other1);

    }
    ;

    return otherDOM;
}

