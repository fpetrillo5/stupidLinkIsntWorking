/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
"use strict";

function twoDishes() {


    var twoDishDOM = document.createElement("div");

    var pastaSaladObj = MakeDish({

        name: "Pasta Salad",
        cost: "10.00",
        description: "An olive oil based based cold salad with fresh indgredients",
        pic: "pics/blockParty6.jpg"
    });

    var pastaSaladNameButton = document.createElement('button');
    pastaSaladNameButton.innerHTML = 'Change Name of Dish: ';
    twoDishDOM.appendChild(pastaSaladNameButton);

    var pastaSaladNameInput = document.createElement("input");
    pastaSaladNameInput.setAttribute("type", "text");
    twoDishDOM.appendChild(pastaSaladNameInput);

    var pastaSaladCostButton = document.createElement('button');
    pastaSaladCostButton.innerHTML = 'Change Cost of Dish: ';
    twoDishDOM.appendChild(pastaSaladCostButton);

    var pastaSaladCostInput = document.createElement("input");
    pastaSaladCostInput.setAttribute("type", "text");
    twoDishDOM.appendChild(pastaSaladCostInput);

    var pastaSaladDescriptionButton = document.createElement('button');
    pastaSaladDescriptionButton.innerHTML = 'Change Description of Dish: ';
    twoDishDOM.appendChild(pastaSaladDescriptionButton);

    var pastaSaladDescriptionInput = document.createElement("input");
    pastaSaladDescriptionInput.setAttribute("type", "text");
    twoDishDOM.appendChild(pastaSaladDescriptionInput);





    twoDishDOM.appendChild(pastaSaladObj);

    var deviledEggsObj = MakeDish({
        name: "Deviled Eggs",
        cost: "8.00",
        description: "A mayo based filling of cooked eggyolks piped into halved hardboiled egg white",
        pic: "pics/blockParty7.jpg"
    });

    var deviledEggsNameButton = document.createElement('button');
    deviledEggsNameButton.innerHTML = 'Change Name of Dish: ';
    twoDishDOM.appendChild(deviledEggsNameButton);

    var deviledEggsNameInput = document.createElement("input");
    deviledEggsNameInput.setAttribute("type", "text");
    twoDishDOM.appendChild(deviledEggsNameInput);

    var deviledEggsCostButton = document.createElement('button');
    deviledEggsCostButton.innerHTML = 'Change Cost of Dish: ';
    twoDishDOM.appendChild(deviledEggsCostButton);

    var deviledEggsCostInput = document.createElement("input");
    deviledEggsCostInput.setAttribute("type", "text");
    twoDishDOM.appendChild(deviledEggsCostInput);

    var deviledEggsDescriptionButton = document.createElement('button');
    deviledEggsDescriptionButton.innerHTML = 'Change Description of Dish: ';
    twoDishDOM.appendChild(deviledEggsDescriptionButton);

    var deviledEggsDescriptionInput = document.createElement("input");
    deviledEggsDescriptionInput.setAttribute("type", "text");
    twoDishDOM.appendChild(deviledEggsDescriptionInput);



    twoDishDOM.appendChild(deviledEggsObj);

    return twoDishDOM;
}

