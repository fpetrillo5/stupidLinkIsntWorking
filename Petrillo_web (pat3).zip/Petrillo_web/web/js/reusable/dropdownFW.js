/* 
 have to pass in variable names not dropHeader and such
 */

/*drop function is fired when user clicks on dropHeader
 * the function checks to see if the contents are open 
 * if they are open it closes the dropdown in the show function
 * if they are closed it opens the dropdown in the hide function*/
function dropdownFW() {

    /*This allows the user to close the dropdowns by clicking anywhere on page
     * except for the dropdown items itself
     * line 55 checks to make sure we are not trying to open the dropdown
     * the loop grabs all the items in the dropdowns
     * and checks to see if they are showing
     * if they are showing they are closed by remove*/
    window.onclick = function (event) {
        if (event.target.matches('.dropHeader')) {
            var clickedEle = event.target;

            // getElementsByClassName returns an array - add [0] to access the first element of that array.
            var nextEle = clickedEle.parentElement.getElementsByClassName("dropContent")[0];


            if (nextEle.classList.contains("show")) {
                hide(nextEle);

            } else {
                show(nextEle);

            }
            //have to close all other dropcontents
            toggle(nextEle);


        } else {
            hideAllContentsBut(null);



        }

        function hideAllContentsBut(ele) {
            var dropdowns = document.getElementsByClassName("dropContent");
            console.log(dropdowns);
            var i;
            for (i = 0; i < dropdowns.length; i++) {
                var openDropdown = dropdowns[i];
                if (ele !== openDropdown) {
                    if (openDropdown.classList.contains('show')) {
                        // openDropdown.classList.remove('show');
                        hide(openDropdown);
                    }
                }

            }
        }

        function hide(ele) {
            ele.classList.remove("show");
            ele.classList.add("hide");
        }

        function show(ele) {
            ele.classList.remove("hide");
            ele.classList.add("show");
        }

        //closes non clicked on 
        function toggle(ne) {
            var dd = document.getElementsByClassName("dropContent");
            var j;
            for (j = 0; j < dd.length; j++) {
                var od = dd[j];
                if (od !== ne) {
                    hide(od);
                }
            }
        }
    };
    
}









