/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*  
 * This function shall return a div that contains an HTML table full of the values found 
 * in objList (pattern your code after 32_makeTable_prettier, meaning that your HTML table 
 * shall have column headings, actual images, and alignment according to data type). 
 *   
 * Your code shall add an onclick event to each head column heading (th tag) such that when 
 * the user clicks on the heading, an alert window pops up saying the original property 
 * name of the data that's in the column (not the prettyColumHeading that shows in its 
 * innerHTML) and ALSO, "forward" or "reverse". The first time you click any column heading, 
 * the alert shall say "forward", but there after, each column heading click shall toggle 
 * between forward and reverse (for that column). 
 * 
 * Here's an example of the syntax for an alert statement: 
 * 
 *     alert("hello"+x);
 * 
 */
//changed the input from ObjList to list
function makeTableWithClickEvents (list) {
    
    
    // Add data as th or td (based on eleType) to row of HTML table.
    function addToRow(eleType, row, data, align) {
        var ele = document.createElement(eleType);
        ele.innerHTML = data;
        ele.style.textAlign = align;
        row.appendChild(ele);
        
        return ele;  // future code may need a reference to this dom object
    }

    function alignment(val) {

        // check if date
        var parsedDate = Date.parse(val);
        if (isNaN(val) && (!isNaN(parsedDate))) {
            return "center";
        }

        // check if image
        if (val.includes(".png") || val.includes(".jpg")) {
            console.log('is center');
            return "center";
        }

        // check if numeric (remove $ and , and then check if numeric)
        var possibleNum = val.replace("$", "");
        possibleNum = possibleNum.replace(",", "");
        if (isNaN(possibleNum)) {
            console.log("not a num - left");
            return "left";
        }

        return "right"; // it's a number

    } // alignment

    function prettyColumnHeading(propName) {

        if (propName.length === 0) {
            return "";
        }

        // studentId --> Student Id
        // capitalize first letter
        var newHdg = propName.charAt(0).toUpperCase();
        // iterate through all characters, inserting space before any capital letters.
        for (var i = 1; i < propName.length; i++) {
            if (propName.charAt(i) < "a") {
                newHdg += " ";
            }
            newHdg += propName.charAt(i);
        }

        return newHdg;
    } // prettyColumnHeading


    // Main Program.
    //Our job is to allow the user to click on these tds. When they click on a td its supposed to show us the 
    //field name that was used to create that column. And its supposed to toggle between forward and reverse for that
    //column.
    //lets start by making an alert that will at least say whats the name of the column of the data that was put in 
    //that column.
    var div = document.createElement("div");

    // Create a new HTML table (DOM object) and append 
    // that into the page. 
    var newTable = document.createElement("table");
    
    //slap newTable onto div so it works instead of changing everything to div
    div.appendChild(newTable);

    // Create a header for table and put a row in the header
    var tableHead = document.createElement("thead");
    newTable.appendChild(tableHead);
    var tableHeadRow = document.createElement("tr");
    tableHead.appendChild(tableHeadRow);

    // create one column header per property with column header content
    // matching the property name
    var obj = list[0];
    console.log(obj);
    for (var prop in obj) {
        // we will add var myHeader
        var myHeader = addToRow("th", tableHeadRow, prettyColumnHeading(prop), alignment(obj[prop]));
        //we add an onclixk function
        
        myHeader.propName = prop;//created custom property
        myHeader.direction = "forward"; //toggle property
        myHeader.onclick = function() {
            //if you do alert("property name is " + prop); it will only give last propeerty name
            //because that is what is stored in prop after the for loop runs
            //
            //random aside hoisting is whenever you use variable for 1st time - it behaves like it was declared
            //at the beginning of the function. Bubbling up to the top of the function body.
            
            //the keyword this means the dom element that is involved in the event. "this" means the header that is
            //being clicked upon. The innerHTML will give us the capitalized version of the property
           // alert("property name is " + this.innerHTML);
           
           //this.propName, which we assigned prop to above, will give us the real property in all in its ugly lowercase letters
           //myHeader iterated throught the first th, the second th... But when they click on it myHeader is already at the 
           //end. But the keyword this references the header that has been clicked on. Since we stored the prop in the 
           //variable propName we should have it.
           //What i want you to take away is if you are going to be iterating over multiple elements, maybe you are creating
           //those elements like we are doing here. And for each of those elements, you want like a hover event or a click
           //event, And if you want those things to be doing something specific. You need to store whatever is relevant right
           // in that element when you build it. Then you need to reference that element with the keyword this.
           
           //alert("property name is " + this.propName);
           
           //okay, we have a custom property called direction, We get to just make it up whatever we want to call it.
           //its like making up a variable name, we initially said it to forward. Then when we click the header, its
           //going to make it reverse. And if its going to flip flop it so we dont need count.
           
           if(this.direction === "forward"){
               this.direction = "reverse";
           } else {
               this.direction = "forward";
           }
           alert(this.direction);
        };
        //When you guys are doing your tutorial coding, which is coming up soon. You are going to be doing some complex
        //component, its very likely that you will be iterating through a list and creating html components and 
        //adding some event handling to those compnents. So you are going to do want to take note of this technique where
        // you put whatever you are going to need for your event directly in that dom element. And then when you are 
        //in that event handler code. You want to reuse the keyword this to reference the dom element that has been 
        //clicked on or hovered over.or something.
    }
    
    

    // Add one row (to HTML table) per element in the array.
    // Each array element has a list of properties that will become 
    // td elements (Table Data, a cell) in the HTML table. 
    
    var tableBody = document.createElement("tbody");
    newTable.appendChild(tableBody);
    for (var i in list) {
        var tableRow = document.createElement("tr");
        tableBody.appendChild(tableRow);

        // create one table data <td> content matching the property name
        var obj = list[i];
        console.log(obj);
        for (var prop in obj) {
            //no need for variable here because we dont plan on doing anything with them.
            addToRow("td", tableRow, obj[prop], alignment(obj[prop]));
        }
    }

    //return newTable;

    // you replace this code here... 
   // div.innerHTML = "your answer for makeTableWithClickEvents";
     return div;
}
